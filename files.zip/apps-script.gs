/**
 * NCS-CORPORATION-SRL — Backend de Apps Script para el catálogo y el admin.
 *
 * CAMBIOS PRINCIPALES respecto a la versión anterior (ver CAMBIOS.md para el detalle):
 *  1. FIX CRÍTICO: al editar un producto ya no se borran las columnas que el
 *     formulario del admin no envía (por ejemplo "svg"). Antes, cada edición
 *     reescribía la fila completa y ponía '' en cualquier columna no incluida
 *     en el payload -> esto causaba "cortes de información" reales en la hoja.
 *  2. Cache de 8 segundos para la lista pública (CacheService) que se invalida
 *     automáticamente apenas se guarda/oculta/borra un producto, así el
 *     catálogo se actualiza casi al instante sin sobrecargar la hoja con
 *     lecturas repetidas de cada visitante.
 *  3. LockService para evitar que dos guardados simultáneos pisen datos.
 *  4. Nuevas acciones: toggleActive (ocultar/mostrar sin borrar) y delete
 *     (borrar fila definitivamente), usadas por el nuevo admin.html.
 *  5. action=admin_list devuelve TODOS los productos (activos e inactivos)
 *     para que el panel admin pueda gestionar lo que está oculto. La acción
 *     "list" (la que usa el catálogo público) sigue mostrando solo activos.
 *  6. Token opcional de administrador (ADMIN_TOKEN) para proteger upsert /
 *     delete / toggleActive / uploadImage. Si lo dejas vacío, no se exige.
 */

const SHEET_NAME = 'Productos';
const DRIVE_FOLDER_ID = ''; // Opcional: pega aqui el ID de una carpeta de Drive para imagenes.

// Opcional pero recomendado: pon aqui una palabra/clave secreta y copia la
// misma clave en el campo "Token admin" de admin.html. Mientras esta
// constante esté vacía, cualquiera que tenga la URL del Apps Script podría
// editar el catálogo sin pasar por tu panel admin.
const ADMIN_TOKEN = '';

const CACHE_PREFIX = 'ncs_products_v2_';
const CACHE_TTL_SECONDS = 8; // tiempo que se reutiliza la lista publica antes de releer la hoja

// Esquema simplificado a pedido del cliente. Solo estos campos se guardan y se
// muestran. id/activo/updated_at son internos (no aparecen en el formulario
// pero el sistema los necesita para identificar, ocultar y fechar la fila).
const HEADERS = [
  'id',
  'activo',
  'oem',
  'alterno',
  'origen',
  'marca',
  'descripcion',
  'medida',
  'precio',
  'cantidad_stock',
  'imagen_url',
  'updated_at'
];

function doGet(e) {
  e = e || {};
  const params = e.parameter || {};
  const action = (params.action || 'list').toLowerCase();
  if (action === 'setup') return jsonResponse(setupSheet_());
  if (action === 'admin_list') return jsonResponse({ products: listProducts_(true) });
  return jsonResponse({ products: listProducts_(false), generated_at: new Date().toISOString() });
}

function doPost(e) {
  try {
    const body = parseBody_(e);
    const action = String(body.action || '').toLowerCase();

    if (['uploadimage', 'upsert', 'delete', 'toggleactive'].indexOf(action) !== -1) {
      checkToken_(body);
    }

    if (action === 'uploadimage') return jsonResponse(uploadImage_(body));
    if (action === 'upsert') return jsonResponse(upsertProduct_(body.product || body));
    if (action === 'delete') return jsonResponse(deleteProduct_(body.id));
    if (action === 'toggleactive') return jsonResponse(toggleActive_(body.id, body.activo));

    return jsonResponse({ ok: false, error: 'Accion no soportada.' });
  } catch (error) {
    return jsonResponse({ ok: false, error: error.message || String(error) });
  }
}

function checkToken_(body) {
  if (!ADMIN_TOKEN) return; // sin token configurado = sin verificacion
  if (String(body.token || '') !== ADMIN_TOKEN) {
    throw new Error('Token de administrador invalido o ausente.');
  }
}

function setupSheet_() {
  const sheet = getSheet_();
  const currentHeaders = sheet.getLastRow()
    ? sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), HEADERS.length)).getValues()[0]
    : [];

  if (!currentHeaders.filter(Boolean).length) {
    sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
    sheet.setFrozenRows(1);
  } else {
    const missingHeaders = HEADERS.filter(header => currentHeaders.indexOf(header) === -1);
    if (missingHeaders.length) {
      sheet
        .getRange(1, currentHeaders.length + 1, 1, missingHeaders.length)
        .setValues([missingHeaders]);
    }
  }

  return { ok: true, headers: HEADERS };
}

/**
 * Devuelve la lista de productos. Si includeInactive es false (catálogo
 * público) se usa un cache corto para que muchas visitas simultáneas no
 * generen una lectura de la hoja por cada una. El cache se invalida solo
 * (invalidateCache_) en cuanto se guarda, oculta o borra un producto, asi
 * que un cambio del admin llega al catálogo en segundos, no en minutos.
 */
function listProducts_(includeInactive) {
  const cache = CacheService.getScriptCache();
  const cacheKey = CACHE_PREFIX + (includeInactive ? 'all' : 'active');

  if (!includeInactive) {
    const cached = cache.get(cacheKey);
    if (cached) return JSON.parse(cached);
  }

  const sheet = getSheet_();
  setupSheet_();
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];

  const headers = values.shift().map(String);
  let rows = values
    .filter(row => row.some(Boolean))
    .map(row => rowToObject_(headers, row));

  if (!includeInactive) {
    rows = rows.filter(product => String(product.activo || 'SI').toUpperCase() !== 'NO');
    cache.put(cacheKey, JSON.stringify(rows), CACHE_TTL_SECONDS);
  }

  return rows;
}

function invalidateCache_() {
  const cache = CacheService.getScriptCache();
  cache.remove(CACHE_PREFIX + 'active');
  cache.remove(CACHE_PREFIX + 'all');
}

/** Ejecuta fn() con un lock de hoja para evitar que dos guardados a la vez se pisen. */
function withLock_(fn) {
  const lock = LockService.getScriptLock();
  const gotLock = lock.tryLock(10000);
  if (!gotLock) {
    throw new Error('El sistema esta ocupado procesando otro cambio. Intenta de nuevo en unos segundos.');
  }
  try {
    return fn();
  } finally {
    lock.releaseLock();
  }
}

function upsertProduct_(product) {
  return withLock_(() => {
    const sheet = getSheet_();
    setupSheet_();
    const values = sheet.getDataRange().getValues();
    const headers = values[0].map(String);
    const idIndex = headers.indexOf('id');
    const id = String(product.id || product.oem || Utilities.getUuid()).trim();
    if (!id) throw new Error('Falta el codigo OEM del producto.');
    product.id = id;
    product.updated_at = new Date();

    let targetRow = -1;
    for (let i = 1; i < values.length; i++) {
      if (String(values[i][idIndex]) === id) {
        targetRow = i + 1;
        break;
      }
    }

    let row;
    if (targetRow > 0) {
      // FIX: antes esto era headers.map(h => product[h] ?? '') sin condicion,
      // lo que borraba cualquier columna que el admin no conociera (ej. "svg").
      // Ahora: si el admin envia la columna (aunque sea como '' a proposito),
      // se respeta su valor. Si la columna NO viene en el payload, se
      // conserva lo que ya habia en la hoja.
      const existingRow = values[targetRow - 1];
      row = headers.map((header, i) => {
        if (Object.prototype.hasOwnProperty.call(product, header)) {
          return product[header] ?? '';
        }
        return existingRow[i] ?? '';
      });
      sheet.getRange(targetRow, 1, 1, headers.length).setValues([row]);
    } else {
      row = headers.map(header => product[header] ?? '');
      sheet.appendRow(row);
    }

    invalidateCache_();
    return { ok: true, id };
  });
}

function deleteProduct_(id) {
  return withLock_(() => {
    const targetId = String(id || '').trim();
    if (!targetId) throw new Error('Falta id del producto a eliminar.');

    const sheet = getSheet_();
    const values = sheet.getDataRange().getValues();
    const headers = values[0].map(String);
    const idIndex = headers.indexOf('id');

    for (let i = 1; i < values.length; i++) {
      if (String(values[i][idIndex]) === targetId) {
        sheet.deleteRow(i + 1);
        invalidateCache_();
        return { ok: true, id: targetId };
      }
    }
    throw new Error('No se encontro un producto con ese id.');
  });
}

/** Oculta o muestra un producto sin borrar la fila (columna "activo" = SI/NO). */
function toggleActive_(id, forcedValue) {
  return withLock_(() => {
    const targetId = String(id || '').trim();
    if (!targetId) throw new Error('Falta id del producto.');

    const sheet = getSheet_();
    const values = sheet.getDataRange().getValues();
    const headers = values[0].map(String);
    const idIndex = headers.indexOf('id');
    const activoIndex = headers.indexOf('activo');

    for (let i = 1; i < values.length; i++) {
      if (String(values[i][idIndex]) === targetId) {
        const current = String(values[i][activoIndex] || 'SI').toUpperCase();
        const next = forcedValue ? String(forcedValue).toUpperCase() : (current === 'NO' ? 'SI' : 'NO');
        sheet.getRange(i + 1, activoIndex + 1).setValue(next);
        invalidateCache_();
        return { ok: true, id: targetId, activo: next };
      }
    }
    throw new Error('No se encontro un producto con ese id.');
  });
}

function uploadImage_(body) {
  if (!body.dataUrl) throw new Error('Falta dataUrl.');

  const matches = String(body.dataUrl).match(/^data:(.+);base64,(.+)$/);
  if (!matches) throw new Error('Formato de imagen invalido.');

  const mimeType = body.mimeType || matches[1];
  const extension = mimeType.split('/').pop() || 'png';
  const filename = body.filename || `producto-${Date.now()}.${extension}`;
  const bytes = Utilities.base64Decode(matches[2]);
  const blob = Utilities.newBlob(bytes, mimeType, filename);
  const folder = DRIVE_FOLDER_ID ? DriveApp.getFolderById(DRIVE_FOLDER_ID) : DriveApp.getRootFolder();
  const file = folder.createFile(blob);
  try {
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  } catch (error) {
    throw new Error('La imagen se subio a Drive, pero no se pudo hacer publica. Revisa permisos de uso compartido en Drive.');
  }

  const fileId = file.getId();
  return {
    ok: true,
    fileId: fileId,
    // Formato thumbnail: es el mas estable hoy para <img> en sitios externos.
    // El catalogo y el admin igual generan variantes de respaldo a partir del
    // fileId por si Google bloquea temporalmente un host concreto.
    url: `https://drive.google.com/thumbnail?id=${fileId}&sz=w1000`
  };
}

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
}

function rowToObject_(headers, row) {
  return headers.reduce((obj, header, index) => {
    let value = row[index];
    if (value instanceof Date) value = value.toISOString();
    obj[header] = value;
    return obj;
  }, {});
}

function parseBody_(e) {
  if (!e.postData || !e.postData.contents) return {};
  try {
    return JSON.parse(e.postData.contents);
  } catch (error) {
    throw new Error('JSON invalido recibido por Apps Script.');
  }
}

function jsonResponse(payload) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}
